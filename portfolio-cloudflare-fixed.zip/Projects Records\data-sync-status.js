// Data Sync Status and Notification System
// Shows users why data isn't syncing between devices

class DataSyncManager {
    constructor() {
        this.showSyncStatus();
        this.setupSyncNotification();
    }

    showSyncStatus() {
        // Check if we're on static HTML (no backend)
        const isStaticHTML = window.location.protocol === 'file:' || 
                           window.location.hostname === 'localhost' ||
                           !window.firebase;

        const statusDiv = document.createElement('div');
        statusDiv.id = 'sync-status';
        statusDiv.style.cssText = `
            position: fixed;
            top: 10px;
            right: 10px;
            background: #ff9800;
            color: white;
            padding: 10px 15px;
            border-radius: 8px;
            font-size: 12px;
            z-index: 10000;
            max-width: 300px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        `;

        if (isStaticHTML) {
            statusDiv.innerHTML = `
                <div style="margin-bottom: 10px;">
                    <strong>📱 Local Storage Mode</strong>
                </div>
                <div style="font-size: 11px; line-height: 1.4;">
                    Your data is saved locally on this device only.
                    <br><br>
                    <strong>Why no cross-device sync:</strong><br>
                    • Static HTML files (no server)<br>
                    • Each browser/device is isolated<br>
                    • No backend to sync data<br>
                    <br>
                    <strong>Solutions:</strong><br>
                    1. <strong>Use same device/browser</strong> for continuity<br>
                    2. <strong>Setup Firebase Hosting</strong> for real sync<br>
                    3. <strong>Export/Import data</strong> manually
                </div>
            `;
        } else {
            statusDiv.innerHTML = `
                <div style="margin-bottom: 10px;">
                    <strong>🔥 Cloud Sync Mode</strong>
                </div>
                <div style="font-size: 11px; line-height: 1.4;">
                    Data sync is enabled via Firebase.
                    <br><br>
                    <strong>Features:</strong><br>
                    • Cross-device synchronization<br>
                    • Real-time data updates<br>
                    • Cloud backup included<br>
                    • Multi-user support
                </div>
            `;
        }

        document.body.appendChild(statusDiv);

        // Auto-hide after 10 seconds
        setTimeout(() => {
            if (statusDiv.parentNode) {
                statusDiv.parentNode.removeChild(statusDiv);
            }
        }, 10000);
    }

    setupSyncNotification() {
        // Show notification about data sync status
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            background: #333;
            color: white;
            padding: 15px 20px;
            border-radius: 8px;
            font-size: 13px;
            z-index: 9999;
            max-width: 400px;
            text-align: center;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        `;

        const isStaticHTML = window.location.protocol === 'file:' || 
                           window.location.hostname === 'localhost' ||
                           !window.firebase;

        notification.innerHTML = isStaticHTML ? 
            '💾 Data saved locally. Use same device for continuity.' :
            '🔥 Real-time sync enabled. Changes sync across all devices.';

        document.body.appendChild(notification);

        // Auto-hide after 8 seconds
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 8000);
    }

    // Method to manually show sync status
    showSyncInfo() {
        this.showSyncStatus();
    }
}

// Initialize when page loads
document.addEventListener('DOMContentLoaded', () => {
    new DataSyncManager();
});

// Export for manual access
window.DataSyncManager = DataSyncManager;
